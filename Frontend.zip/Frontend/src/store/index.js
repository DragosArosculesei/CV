import Vue from 'vue'
import Vuex from 'vuex'

// import example from './module-example'

Vue.use(Vuex)

/*
 * If not building with SSR mode, you can
 * directly export the Store instantiation;
 *
 * The function below can be async too; either use
 * async/await or return a Promise which resolves
 * with the Store instance.
 */

export default function (/* { ssrContext } */) {
  const Store = new Vuex.Store({
    modules: {
      // example
    },
    state: {
      name: '',
      userType: '',
      userId: ''

    },
    mutations: {
      SET_NAME (state, setValue) {
        state.name = setValue
      },
      SET_USER_TYPE (state, setValue) {
        state.userType = setValue
      },
      SET_USER_ID (state, setValue) {
        state.userId = setValue
      }
    },
    actions: {
      setUserId ({ commit }, setValue) {
        commit('SET_USER_ID', setValue)
      },
      setName ({ commit }, setValue) {
        commit('SET_NAME', setValue)
      },
      setUserType ({ commit }, setValue) {
        commit('SET_USER_TYPE', setValue)
      }
    }
    // enable strict mode (adds overhead!)
    // for dev mode only
    // strict: process.env.DEBUGGING
  })

  return Store
}
