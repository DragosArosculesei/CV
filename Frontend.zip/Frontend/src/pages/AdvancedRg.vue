<template>
  <div class="advanced">
    <p class="advanced-workouts">Advanced</p>
    <div class="regular-button">
      <q-btn flat to="PPLregular" class="ppl-regular-client">PPL Regular Client</q-btn>
    </div>
    <p class="description2">
      Description: A 3 day split that<br />
      focuses more on types of<br />
      muscle groups and increases<br />
      muscle mass and strenght over<br />
      time.
    </p>
    <p class="duration50-minutes">Duration:30-90 minutes</p>
    <div class="relative-wrapper-one">
      <div class="premium-button">
        <q-btn flat class="ppl-regular-client">PPL Premium Client</q-btn>
      </div>
      <div class="lock">
        <img
          alt=""
          class="vector"
          src="https://static.overlay-tech.com/assets/c2289327-6cec-449b-ae31-e4e1eb4978a1.svg"
        />
      </div>
    </div>
    <p class="description2">
      Description: An improved version<br />
      of the Push/Pull/Legs routine.<br />
      This workout contains exercises that <br />
      focuses even on isolation movements<br />
      for maximum results.
    </p>
    <p class="duration50-minutes-two">
      Duration:30-90 minutes
    </p>
    <q-btn flat to="/Levels" class="back-btn"><p class="back">Back</p></q-btn>
  </div>
</template>

<script>
export default {
  name: "Advanced"
};
</script>

<style lang="scss" scoped>
.advanced {
  background-size: 100% 100%;
  background-position: center;
  background: url("https://static.overlay-tech.com/assets/707d6ee8-8580-434a-853c-da4565d8d246.png"),
    linear-gradient(
      rgb(0, 0, 0),
      rgb(0, 0, 0)
    ),
    rgba(255, 255, 255, 0.867)
  no-repeat;
  padding: 56px 53px 126px 54px;
  display: flex;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  flex-direction: column;
  align-items: flex-start;
}
.advanced-workouts {
  font-family: "Roboto";
  font-size: 36px;
  font-weight: 700;
  line-height: normal;
  color: rgba(255, 255, 255, 0.867);
  margin-bottom: 74px;
}
.regular-button {
  background-color: rgba(255, 245, 7, 1);
  margin-bottom: 14px;
  border-radius: 7px;
  padding: 14px 81px 14px 80px;
  display: flex;
  align-items: center;
  margin-left: -25px;
}
.ppl-regular-client {
  color: #1d1d1d;
  text-align: center;
}
.description2 {
  max-width: 297px;
  color:$grey-2;
  margin-bottom: 24px;
  font-weight:medium;
  margin-left: -25px;
}
.duration50-minutes {
  color:$grey-2;
  margin-bottom: 80px;
  font-weight:medium;
  margin-left: -25px;
}
.relative-wrapper-one {
  margin-bottom: 14px;
  position: relative;
}
.premium-button {
  background-color: rgba(255, 245, 7, 1);
  border-radius: 7px;
  padding: 14px 76px 14px 75px;
  position: relative;
  margin-left: -25px;
}
.lock {
  padding: 4px 8px;
  display: flex;
  align-items: center;
  position: absolute;
  right: 0;
  top: 12px;
}
.vector {
  flex: 1;
  align-self: stretch;
  object-fit: cover;
}
.duration50-minutes-two {
  color: $grey-2;
  margin-bottom: 24px;
  font-weight:medium;
  margin-left: -25px;
}
.back-btn {
  background-color: #1d1d1d;
  border-radius: 7px;
  padding: 14px 134px 14px 133px;
  display: flex;
  align-items: center;
  margin-left: -25px;
}
.back {
  color: rgba(255, 255, 255, 0.867);
  text-align: center;
}
</style>
