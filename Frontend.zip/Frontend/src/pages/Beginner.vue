<template>
  <div class="beginner">
    <p class="begginer-workouts">Beginner</p>
    <div class="regular-button">
      <q-btn flat to="fullbodyRg" class="full-body-regular-client">
        FullBody Regular Client
      </q-btn>
    </div>
    <p class="description2">
      Description: A free full body<br />
      workout that trains the<br />
      whole body for any beginner. <br />
      This workout builds strenght<br />
      and boosts metabolism for weight loss
    </p>
    <p class="duration50-minutes">Duration:between 30-70 minutes</p>
    <div class="relative-wrapper-one">
      <div class="premium-button">
        <q-btn to="fullbody1" flat class="full-body-regular-client">
          FullBody Premium Client
        </q-btn>
      </div>
    </div>
    <p class="description2">
      Description: An updated version<br />
      of the fullbody workout that <br />
      includes better exercises and <br />
      tips that will maximize your goals<br />
    </p>
    <p class="duration50-minutes-two">
      Duration:between 30-70 minutes
    </p>
    <q-btn flat to="/Levels" class="back-btn"><p class="back">Back</p></q-btn>
  </div>
</template>

<script>
export default {
  name: "Beginner"
};
</script>

<style lang="scss" scoped>
.beginner {
  background-size: cover;
  background-position: center;
  background: url("https://static.overlay-tech.com/assets/235a6794-e733-4cd3-abb3-d72ceb445a70.png"),
    linear-gradient(
      rgb(0, 0, 0),
      rgb(0, 0, 0)
    ),
    rgba(255, 255, 255, 0.867) no-repeat;
 padding: 56px 53px 126px 54px;
  display: flex;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  flex-direction: column;
  align-items: flex-start;
}
.begginer-workouts {
  font-family: "Roboto";
  font-size: 36px;
  font-weight: 700;
  line-height: normal;
  color: rgba(255, 255, 255, 0.867);
  margin-bottom: 74px;
}
.regular-button {
  background-color: rgba(255, 245, 7, 1);
  margin-bottom: 14px;
  border-radius: 7px;
  padding: 14px 63px;
  display: flex;
  align-items: center;
  margin-left:-25px;
}
.full-body-regular-client {
  color: #1d1d1d;
  text-align: center;
}
.description2 {
  max-width: 297px;
  color:$grey-2;
  margin-bottom: 24px;
  font-weight:medium;
  margin-left:-25px;
}
.duration50-minutes {
  color:$grey-2;
  margin-bottom: 80px;
  font-weight:medium;
  margin-left:-25px;
}
.relative-wrapper-one {
  margin-bottom: 14px;
  position: relative;
}
.premium-button {
  background-color: rgba(255, 245, 7, 1);
  border-radius: 7px;
  padding: 14px 58px 14px 57px;
  position: relative;
  margin-left: -25px;
}
.vector {
  flex: 1;
  align-self: stretch;
  object-fit: cover;
}
.duration50-minutes-two {
  color:$grey-2;
  margin-bottom: 24px;
  font-weight:medium;
  margin-left:-25px;
}
.back-btn {
  background-color: #1d1d1d;
  border-radius: 7px;
  padding: 14px 134px 14px 133px;
  display: flex;
  align-items: center;
    margin-left: -25px;
}
.back {
  color: rgba(255, 255, 255, 0.867);
  text-align: center;
}
</style>
