<template>
  <div class="flex flex-center login-page">
    <p class="login">Login</p>
    <div class="group-13">
      <div class="group-11">
        <q-input
              class="username"
              v-model="email"
              label="Email"
              type="email"
            ></q-input>
        <img
          alt=""
          class="carbonuser-certification"
          src="https://static.overlay-tech.com/assets/cdf2ef26-ae0b-4a22-b738-9604537c3756.svg"
        />
      </div>
      <div class="group-11">
        <q-input
              class="password"
              v-model="password"
              label="Password"
              type="password"
            ></q-input>
        <img
          alt=""
          class="carbonuser-certification"
          src="https://static.overlay-tech.com/assets/c6e1537b-48bf-4c8f-8d1c-d57bcf819781.svg"
        />
      </div>
    </div>
    <div class="group-15">
      <div class="group-14">
        <q-btn flat class="log-in" v-on:click="onSubmit">Login</q-btn>
      </div>
      <q-btn to="signup" class="become-premium">You don't have an account?Signup</q-btn>
    </div>
  </div>
</template>

<script>
const pathApi = '/api/auth/';
window.Laravel = {csrfToken: '{{ csrf_token() }}'}
export default {
  name: "PageIndex",
  data() {
    return {
      email: null,
      id: null,
      password: null,
      csrfToken : null,
    };
  },
  methods: {
    onSubmit() {
      //this.$router.push({ name: "levels" });
      console.log(window.Laravel)
      this.$axios
        .post(pathApi + "login", {
          email: this.email,
          password: this.password,
          userType: '',
          csrfToken:window.Laravel

        })
        .then((res) => {
          //store in Vuex the user id
          this.$forceUpdate();
          this.userType = res.data.user.user_type;
          console.log(res.data.user);
          this.$store.dispatch('setUserId', res.data.user.id);
          this.$store.dispatch('setUserType', res.data.user.user_type);
          this.$store.dispatch('setName', res.data.user.name);
          this.$router.push({ name: "levels" });
        })
        .catch((err) => {
          console.log(err);
          this.$q.notify({
            color: "red-5",
            position: "center",
            textColor: "white",
            icon: "warning",
            message: "The user or password is incorrect",
          });
        });
    },
    onSignup() {
      this.$router.push({ name: "signup" });
    },
  },
};
</script>

<style lang="scss" scoped>
.login-page {
  background-size: cover;
  background-position: center;
  background: url("https://static.overlay-tech.com/assets/544c69cb-9ae4-4210-8818-9185e9bf1cc7.png"),
    linear-gradient(
      rgba(196, 196, 196, 1),
      rgba(196, 196, 196, 1)
    ) no-repeat;
  padding: 56px 53px 126px 54px;
  display: flex;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  flex-direction: column;
  align-items: flex-start;
}
.login {
  font-family: "Roboto";
  font-size: 36px;
  font-weight: 600;
  line-height: normal;
  color: #ffff;
  text-align: center;
  margin-bottom: 77px;
  margin-left: 2px;
}
.group-13 {
  margin-bottom: 399px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.group-11 {
  background-color: rgba(196, 196, 196, 1);
  border-radius: 10px;
  padding: 8px 40px;
  display: flex;
  align-items: center;
  &:not(:last-of-type) {
    margin-bottom: 25px;
  }
}
.username {
  font-family: "Roboto";
  font-size: 17px;
  font-weight: 600;
  line-height: normal;
  color: #1d1d1d;
}

.password {
  font-family: "Roboto";
  font-size: 17px;
  font-weight: 600;
  line-height: normal;
  color: #1d1d1d;
  text-align: center;
}
.group-15 {
  margin-left: -25px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.group-14 {
  background-color: rgb(236, 244, 5);
  margin-bottom: 9px;
  border-radius: 7px;
  padding: 14px 129px;
  display: flex;
  align-items: center;
}
.log-in {
  color: #1d1d1d;
  text-align: center;
}
.become-premium {
  font-family: "Roboto";
  font-size: 15px;
  font-weight: 700;
  line-height: normal;
  color: #ffff;
}
</style>
