<template>
  <div class="intermediate">
    <p class="intermediate-workouts">
      Intermediate
    </p>
    <div class="regular-button">
      <q-btn to="ULregular" flat class="upper-lower-regular-client">
        Upper/Lower Regular Client
      </q-btn>
    </div>
    <p class="description2">
      Description: A new variation of<br />
      workout that focuses on a split<br />
      type of training working all <br />
      types of muscles in 2 separate<br />
      days.
    </p>
    <p class="duration50-minutes">Duration:30-80 minutes</p>
    <div class="relative-wrapper-one">
      <div class="premium-button">
        <q-btn flat to="ULpremium" class="upper-lower-regular-client">
          Upper/Lower Premium Client
        </q-btn>
      </div>
    </div>
    <p class="description2">
      Description: An optimized version<br />
      of the Upper/Lower split<br />
      focused to improve the muscle <br />
      growth a lot faster than the<br />
      regular version of the workout.
    </p>
    <p class="duration50-minutes-two">
      Duration:30-80 minutes
    </p>
    <q-btn flat to="/Levels" class="back-btn"><p class="back">Back</p></q-btn>
  </div>
</template>

<script>
export default {
  name: "Intermediate"
};
</script>

<style lang="scss" scoped>
.intermediate {
  background-size: 100% 100%;
  background-position: center;
  background: url("https://static.overlay-tech.com/assets/41b10469-93e4-471e-bbc0-6fae223077ac.png"),
    linear-gradient(
      rgb(0, 0, 0),
      rgb(0, 0, 0)
    ),
    rgba(255, 255, 255, 0.867)
  no-repeat;
 padding: 56px 53px 126px 54px;
  display: flex;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  flex-direction: column;
  align-items: flex-start;
}
.intermediate-workouts {
  font-family: "Roboto";
  font-size: 36px;
  font-weight: 700;
  line-height: normal;
  color: rgba(255, 255, 255, 0.867);
  margin-bottom: 80px;
}
.regular-button {
  background-color: rgba(255, 245, 7, 1);
  margin-bottom: 14px;
  margin-left: -25px;
  border-radius: 7px;
  padding: 14px 47px;
  display: flex;
  align-items: center;
}
.upper-lower-regular-client {
  color: #1d1d1d;
  text-align: center;
}
.description2 {
  max-width: 297px;
  color:$grey-2;
  font-weight:medium;
  margin-bottom: 24px;
  margin-left: -25px;
}
.duration50-minutes {
  color: $grey-2;
  font-weight:medium;
  margin-bottom: 80px;
  margin-left: -25px;
}
.relative-wrapper-one {
  margin-bottom: 14px;
  margin-left: 30px;
  position: relative;
}
.premium-button {
  background-color: rgba(255, 245, 7, 1);
  border-radius: 7px;
  padding: 14px 42px 14px 41px;
  position: relative;
  margin-left:-55px;
}
.lock {
  padding: 4px 8px;
  display: flex;
  align-items: center;
  position: absolute;
  right: 0;
  top: 4px;
}
.vector {
  flex: 1;
  align-self: stretch;
  object-fit: cover;
}
.duration50-minutes-two {
  color: $grey-2;
  font-weight:medium;
  margin-bottom: 24px;
  margin-left: -25px;
}
.back-btn {
  background-color: #1d1d1d;
  margin-left: -25px;
  border-radius: 7px;
  padding: 14px 134px 14px 133px;
  display: flex;
  align-items: center;
}
.back {
  color: #ffffff;
  text-align: center;
}
</style>
