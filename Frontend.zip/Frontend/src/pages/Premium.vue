<template>
  <div class="become-premium-page">
    <div class="rectangle-15"></div>
    <div class="group-17">
      <q-btn flat to="levels" class="cancel">Cancel</q-btn>
      <div class="login-button">
        <q-btn flat class="join-now" v-on:click="joinNow">Join now</q-btn>
      </div>
    </div>
    <p class="benefits-of-premium-member">
      Benefits of premium member:
    </p>
    <p class="full-access-to-all-the-workout-plans-no">
      Full access to all the workout plans<br />
      <br />
      No more ads<br />
      <br />
      30 days free trail<br />
      <br />
      First to get a new update<br />
      <br />
      <strong
        class="full-access-to-all-the-workout-plans-no-emphasis-1"
        >Future Update:<br /> </strong
      ><br />
      1 on 1 coaching<br />
      <br />
      Tracking personal progress<br />
      <br />
      Weekly Challenges<br />
      <br />
      More Workouts
    </p>
    <div class="gggym">
      <img
        alt=""
        class="vector"
        src="https://static.overlay-tech.com/assets/f0ce88b4-fd18-4c0e-acc4-3f520f5475f0.svg"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: "BecomePremiumPage",
  methods: {
    joinNow() {
      this.$axios.post("/api/auth/user/change-user-type", {
        id: this.$store.state.userId,
      }).then((res) => {
        console.log(res);
        this.$store.dispatch("setUserType", "premium");
        this.$router.push({ name: "levels" });
      }).catch((err) => {
        console.log(err);
      });
    }
  }
};
import axios from 'axios';
</script>

<style lang="scss" scoped>
.become-premium-page {
  background: linear-gradient(#1d1d1d, #1d1d1d),
    rgba(254, 252, 252, 1);
  padding: 21px 16px 22px 15px;
  position: relative;
}
.rectangle-15 {
  width: 383px;
  height: 853px;
  background-color: rgba(210, 210, 209, 1);
  border-radius: 15px;
  position: relative;
}
.group-17 {
  display: flex;
  flex-direction: column;
  align-items: center;
  position: absolute;
  left: 66px;
  bottom: 129px;
}
.cancel {
  font-family: "Roboto";
  font-size: 15px;
  font-weight: 700;
  line-height: normal;
  color: rgba(14, 14, 14, 1);
  margin-bottom: 14px;
}
.login-button {
  background-color: rgba(255, 245, 7, 1);
  border-radius: 7px;
  padding: 10px 99px 10px 100px;
  display: flex;
  align-items: center;
}
.join-now {
  color: #1d1d1d;
  text-align: center;
  text-transform: uppercase;
}
.benefits-of-premium-member {
  font-family: "Roboto";
  font-size: 18px;
  font-weight: 900;
  line-height: normal;
  color: #1d1d1d;
  text-align: center;
  text-transform: uppercase;
  position: absolute;
  left: 40px;
  top: 186px;
}
.full-access-to-all-the-workout-plans-no {
  position: absolute;
  left: 40px;
  top: 253px;
  color: #1d1d1d;
}
.full-access-to-all-the-workout-plans-no-emphasis-1 {
  color: #1d1d1d;
}
.gggym {
  padding: 15.86px 6.66px 15.86px 6.65px;
  display: flex;
  align-items: center;
  position: absolute;
  left: 157px;
  top: 40px;
}
.vector {
  flex: 1;
  align-self: stretch;
  object-fit: cover;
}
</style>
