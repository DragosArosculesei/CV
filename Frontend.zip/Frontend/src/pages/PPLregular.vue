<template>
  <div class="wallpaper">
   <q-page class="q-pa-lg">
    <h3 class="text-weight-bold">Upper Lower</h3>
      <q-scroll-area style="height: 600px; width:350px;">
        <div class="text-body1">
          <p>
          Outside/Home vs Gym<br />
          <br />
          Upper day:<br />
          <br />
          3 x max pull-ups(anywhere) <br />
          <br />
          3 x max dips vs 3 x 10 weighted dips (70% 1rm)<br />
          <br />
          3 x max bodyweight rows vs 3 x 10 barbell rows (70% 1rm)<br />
          <br />
          3 x max push-ups vs 3 x 10 dumbbell bench press (70% 1rm)<br />
          <br />
          3 x max bodyweight curls vs 3 x 10 barbell curls (70% 1rm)<br />
          <br />
          3 x max tricep extensions vs 3 x 10 overhead tricep extensions (70% 1rm)<br />
          <br />
          Lower day:<br />
          <br />
          2 x max bodyweight squats vs 2 x 10 barbell squats (70% 1rm)<br />
          <br />
          2 x max nordics vs 2 x 10 leg curls (70% 1rm)<br />
          <br />
          2 x max bodyweight lunges vs 2 x 10 barbell squats (70% 1rm)<br />
          <br />
          2 x max bodyweight calf raises vs 2 x 10 weighted calf raises (70% 1rm)<br />
          <br />
          Rest for 1 minute between sets and exercises<br />
          Repeat this workout 2 times per week<br />
          <br />
          Reminders:<br />
          Inhale on the esentric movement, squeeze at the top, and exhale on the desentric.<br />
          Use proper form and don't ego lift to avoid injuries!<br />
          Never give up!<br />
          1rm = 1 rep max<br />

          </p>
        </div>
      </q-scroll-area>
      <q-btn flat to="/Levels" class="back-btn"><p class="back">Back</p></q-btn>
    </q-page>
   </div>
  </template>

  <script>

  </script>

  <style lang="scss">

  .wallpaper {
    height: 100vh;
    width: 100%;
    background-position: center;
    background: url("https://static.overlay-tech.com/assets/512b3755-69b3-419f-aa88-933a8736e77b.png"),
      #1d1d1d no-repeat center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    display: flex;
  }
  .text-body1{
   color:$grey-1;
    font-size:20px;
  }
  .text-weight-bold{
    font-weight:bold;
    color:$grey-1;
  }
  .back-btn {
    background-color: #1d1d1d;
    border-radius: 7px;
    padding: 14px 134px 14px 133px;
    display: flex;
    align-items: center;
  }
  .back {
    color: rgba(255, 255, 255, 0.867);
    text-align: center;
  }
  </style>
