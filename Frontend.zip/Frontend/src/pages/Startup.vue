<template>
  <q-page>
    <div class=" startup-page">
      <div class="flex flex-center rectangle-19"></div>
      <div>
        <q-btn flat to="signup" class="sign-up">Signup</q-btn>
      </div>
        <div class="flex flex-center login-button">
          <q-btn flat class="log-in" to="login" >Login</q-btn>
       </div>
        <p class="the-perfect-mobile-app-to-workout-anywhe">
          The Perfect mobile app to workout <br />
                      anywhere.
        </p>
      <p class="unleash-the-beast">Unleash the beast</p>
    </div>
  </q-page>
</template>

<script>
export default {

};
</script>


<style lang="scss" scoped>
.startup-page {
  background-color: rgba(255, 255, 255, 0.867);
  padding: 0 1px 0 0;
  position: center;
}
.rectangle-19 {
  height: 100vh;
  width: 100%;
  background-position: center;
  background: url("https://static.overlay-tech.com/assets/481645b6-add8-48da-aab0-ad9da0884cce.png"),
    rgba(196, 196, 196, 1) no-repeat center fixed;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
  display: flex;
}
.sign-up {
  color: #ffffff;
  width: 51px;
  height: 18px;
  position: absolute;
  left: 175px;
  bottom: 119px;
  font-weight:medium;
}
.login-button {
  background-color: rgba(255, 245, 7, 1);
  border-radius: 7px;
  padding: 10px 113px 10px 114px;
  display: flex;
  align-items: center;
  position: absolute;
  left: 50px;
  bottom: 153px;
}
.log-in {
  color: #1d1d1d;
  text-align: center;
  text-transform: uppercase;
  font-weight:medium;
}
.the-perfect-mobile-app-to-workout-anywhe {
  max-width: 312px;
  font-size: 20px;
  font-weight: 400;
  line-height: normal;
  color: rgba(255, 255, 255, 0.867);
  text-align: center;
  position: absolute;
  left: 50px;
  bottom: 290px;
}
.unleash-the-beast {
  font-size: 30px;
  font-weight: 700;
  line-height: normal;
  color: rgba(255, 255, 255, 0.867);
  position: absolute;
  left: 80px;
  bottom: 372px;
}
</style>
