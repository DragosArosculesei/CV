<template>
  <q-page>
    <div class="levels-regular">
      <p class="choose-your-level">Levels Page</p>
      <div class="group-14">
        <q-btn flat v-on:click="checkUserType('beg')" class="beginner"
          >Beginner</q-btn
        >
      </div>
      <div class="group-15">
        <q-btn flat v-on:click="checkUserType('intm')" class="beginner"
          >Intermediate</q-btn
        >
      </div>
      <div class="group-16">
        <q-btn flat v-on:click="checkUserType('adv')" class="beginner"
          >Advanced</q-btn
        >
      </div>
      <div class="group-17">
        <q-btn flat class="beginner" v-on:click="onLogout">Logout</q-btn>
      </div>
      <q-btn v-on:click="checkUserType('prm')" flat class="become-a-premium-member">
        Premium Member Benefits
      </q-btn>
    </div>
  </q-page>
</template>

<script>
export default {
  name: "PageIndex",
  props: {},
  data() {
    return {
      username: "",
      premium: false,
      password: ""
    };
  },
  methods: {
    checkUserType(buttonName) {
      let userType = this.$store.state.userType;

      if (userType === "premium") {
        if (buttonName === "beg") {
          this.$router.push({ name: "bgn" });
        } else if (buttonName === "intm") {
          this.$router.push({ name: "itm" });
        } else if (buttonName === "adv") {
          this.$router.push({ name: "adv" });
        } else if (buttonName === "prm") {
          this.$router.push({ name: "cancel" });
        }
      } else {
        if (buttonName === "beg") {
          this.$router.push({ name: "bgnrg" });
        } else if (buttonName === "intm") {
          this.$router.push({ name: "itmrg" });
        } else if (buttonName === "adv") {
          this.$router.push({ name: "advrg" });
        } else if (buttonName === "prm") {
          this.$router.push({ name: "premium" });
        }
      }
    },
    onLogout() {
      this.$store.dispatch("setUserId", null);
      this.$store.dispatch("setUserType", null);
      this.$store.dispatch("setName", null);
      this.$router.push({ name: "startup" });
    },
    mounted() {
      this.checkUserType();
    }
  }
};
</script>

<style lang="scss" scoped>
.levels-regular {
  background-size: cover;
  background-position: center;
  background: url("https://static.overlay-tech.com/assets/e27495d2-dc3d-4c67-979e-88523fb9009e.png"),
    linear-gradient(#1d1d1d, #1d1d1d), no-repeat, rgba(255, 255, 255, 0.867);
  padding: 56px 53px 126px 54px;
  display: flex;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  flex-direction: column;
  align-items: flex-start;
}
.choose-your-level {
  font-family: "Roboto";
  font-size: 36px;
  font-weight: 600;
  line-height: normal;
  color: rgba(255, 255, 255, 0.867);
  text-align: center;
  margin-bottom: 144px;
}
.group-14 {
  background-color: rgba(255, 245, 7, 1);
  margin-bottom: 56px;
  border-radius: 7px;
  padding: 14px 118px;
  display: flex;
  align-items: center;
  margin-left: -25px;
}
.beginner {
  color: #1d1d1d;
  text-align: center;
}
.group-15 {
  background-color: rgba(255, 245, 7, 1);
  margin-bottom: 56px;
  border-radius: 7px;
  padding: 14px 104px 14px 103px;
  display: flex;
  align-items: center;
  margin-left: -25px;
}
.group-16 {
  background-color: rgba(255, 245, 7, 1);
  margin-bottom: 218px;
  border-radius: 7px;
  padding: 14px 115px 14px 114px;
  display: flex;
  align-items: center;
  margin-left: -25px;
}
.group-17 {
  background-color: rgba(255, 245, 7, 1);
  margin-bottom: 27px;
  border-radius: 7px;
  padding: 14px 126px 14px 125px;
  display: flex;
  align-items: center;
  margin-left: -25px;
}
.become-a-premium-member {
  color: rgba(255, 255, 255, 0.867);
  text-align: center;
  margin-left: 30px;
}
.vector {
  flex: 1;
  align-self: stretch;
  object-fit: cover;
}
</style>
