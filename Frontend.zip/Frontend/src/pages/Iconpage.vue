<template>
  <q-page class="flex flex-center">
    <div class="flex flex-center icon-page">
      <div class="flex flex-center fa-brandswolf-pack-battalion">
        <img
          alt=""
          class="vector"
          src="https://static.overlay-tech.com/assets/8aa1f7ef-e491-4c15-8f19-055f4e244f25.svg"
        />
      </div>
    </div>
  </q-page>
</template>


<script>
export default {
  name: "PageIndex",
  props: {},
  mounted() {
    setTimeout(() => {
        this.$router.push({ name: "startup" })
      }, 1700)
  },
};
</script>


<style lang="scss" scoped>
.icon-page {
  height: 100vh;
  width: 100%;
  background-position: center;
  background: url("https://static.overlay-tech.com/assets/512b3755-69b3-419f-aa88-933a8736e77b.png"),
    #1d1d1d no-repeat center fixed;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
  display: flex;
}
.fa-brandswolf-pack-battalion {
  padding: 0 21.49px 0 21.88px;
  display: flex;
  align-items: flex-start;
}
.vector {
  flex: 1;
  align-self: stretch;
  object-fit: cover;
}
</style>
