<template>
  <div class="signup-page">
    <p class="register">Register</p>
    <div class="group-8">
      <div class="group-2">
         <q-input
              class="username"
              v-model="name"
              label="Name"
              type="username"
            ></q-input>
        <img
          alt=""
          class="carbonuser-certification"
          src="https://static.overlay-tech.com/assets/1b9a7042-cdfe-4b74-bae6-8743cd0e4cec.svg"
        />
      </div>
      <div class="group-3">
        <q-input
              class="password"
              v-model="password"
              label="Password"
              type="password"
            ></q-input>
        <img
          alt=""
          class="carbonuser-certification"
          src="https://static.overlay-tech.com/assets/4c6b2d00-b0bd-46cb-804f-ca4b63ecc082.svg"
        />
      </div>
      <div class="group-4">
        <q-input
              class="password"
              v-model="password_confirmation"
              label="Confirm Password"
              type="password"
            ></q-input>
        <img
          alt=""
          class="carbonuser-certification"
          src="https://static.overlay-tech.com/assets/11fec04f-f956-448a-88be-e282169b0223.svg"
        />
      </div>
      <div class="group-5">
        <q-input
              class="email-address"
              v-model="email"
              label="Email"
              type="email"
            ></q-input>
        <div class="clarityemail-solid">
          <img
            alt=""
            class="vector"
            src="https://static.overlay-tech.com/assets/79af5301-c21a-4eaf-8365-14481f48fc3c.svg"
          /><img
            alt=""
            class="vector-two"
            src="https://static.overlay-tech.com/assets/40dcfcf3-af53-4104-bec6-6e01423ee950.svg"
          />
        </div>
      </div>
    </div>
    <div class="group-7">
      <div class="group-6">
        <q-btn flat class="sign-up" v-on:click="onSubmit">Signup</q-btn>
      </div>
      <q-btn v-on:click="onLogin" flat class="you-have-an-account-login">
        You have an account? Login
      </q-btn>
    </div>
  </div>
</template>

<script>
const pathApi = '/api/auth/';
window.Laravel = {csrfToken: '{{ csrf_token() }}'}
export default {
  name: "PageIndex",
  props: {},
    data() {
      return {
        name: null,
        boolean: false,
        email: null,
        password: null,
        password_confirmation: null,

    };
  },
  methods: {
    onSubmit() {
      console.log(window.Laravel)
      this.$axios
        .post(pathApi + "register", {
          name: this.name,
          password: this.password,
          password_confirmation: this.password_confirmation,
          email: this.email,
         csrfToken:window.Laravel
        })
        .then((res) => {
          console.log(res);
          this.$router.push({ name: "login" });
        })
        .catch((err) => {
          console.log(err);
          this.$q.notify({
            color: "red-5",
            position: "center",
            textColor: "white",
            icon: "warning",
            message: "Utilizatorul nu a putut fi inregistrat!",
          });
        });
    },
    onLogin() {
      this.$router.push({ name: "login" });
    },
  },
};
</script>

<style lang="scss" scoped>
.signup-page {
  background-size: cover;
  background-position: center;
  background: url("https://static.overlay-tech.com/assets/38ec2df2-bb8e-430b-a96a-b04b3747b59d.png"),
    linear-gradient(
      rgba(196, 196, 196, 1),
      rgba(196, 196, 196, 1)
    ) no-repeat;
  padding: 56px 53px 126px 54px;
  display: flex;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  flex-direction: column;
  align-items: flex-start;
}
.register {
  font-family: "Roboto";
  font-size: 36px;
  font-weight: 600;
  line-height: normal;
  color: rgba(255, 255, 255, 0.867);
  text-align: center;
  margin-bottom: 71px;
}
.group-8 {
  margin-bottom: 200px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.group-2 {
  background-color: rgba(196, 196, 196, 1);
  margin-bottom: 25px;
  border-radius: 7px;
  padding: 10px 16px;
  display: flex;
  align-items: center;

}
.username {
  font-family: "Roboto";
  font-size: 17px;
  font-weight: 600;
  line-height: normal;
  color: #1d1d1d;
  text-align: center;
  margin-top: 4px;
  margin-right: 100px;
}
.carbonuser-certification {
  width: 32px;
  height: 32px;
}
.group-3 {
  background-color: rgba(196, 196, 196, 1);
  margin-bottom: 25px;
  border-radius: 7px;
  padding: 8px 16px;
  display: flex;
  align-items: center;
}
.password {
  font-family: "Roboto";
  font-size: 17px;
  font-weight: 600;
  line-height: normal;
  color: #1d1d1d;
  text-align: center;
  margin-right: 100px;
}
.group-4 {
  background-color: rgba(196, 196, 196, 1);
  margin-bottom: 25px;
  border-radius: 7px;
  padding: 8px 16px;
  display: flex;
  align-items: center;
}
.confirm-password {
  font-family: "Roboto";
  font-size: 17px;
  font-weight: 600;
  line-height: normal;
  color: #1d1d1d;
  text-align: center;
  margin-right: 100px;
}
.group-5 {
  background-color: rgba(196, 196, 196, 1);
  border-radius: 7px;
  padding: 8px 16px;
  display: flex;
  align-items: center;
}
.email-address {
  font-family: "Roboto";
  font-size: 17px;
  font-weight: 600;
  line-height: normal;
  color: #1d1d1d;
  text-align: center;
  margin-right: 100px;
}
.clarityemail-solid {
  padding: 6.57px 1.84px 5.33px 1.72px;
  position: relative;
}
.vector {
  width: 80.38%;
  height: 40.22%;
  position: absolute;
  left: 3.01px;
  top: 5.32px;
}
.vector-two {
  width: 100%;
  height: 100%;
  position: relative;
}
.group-7 {
  margin-left: -25px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.group-6 {
  background-color: rgba(255, 245, 7, 1);
  margin-bottom: 18px;
  border-radius: 7px;
  padding: 14px 124px 14px 123px;
  display: flex;
  align-items: center;
}
.sign-up {
  color: #1d1d1d;
  text-align: center;
}
.you-have-an-account-login {
  font-family: "Roboto";
  font-size: 15px;
  font-weight: 700;
  line-height: normal;
  color: rgba(255, 255, 255, 0.867);
}
</style>
