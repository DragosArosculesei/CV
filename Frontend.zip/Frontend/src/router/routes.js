
const routes = [
  {
    // path: '/',
    // component: () => import('layouts/MainLayout.vue'),
    // children: [
    //   { path: '/', component: () => import('pages/SplashScreen.vue') },
    //   { path: 'login', name:'login' , component: () => import('pages/Login.vue') },
    //   { path: 'generateAWB', name:'generateAWB' , component: () => import('pages/GenerateAWB.vue') },
    //   { path: 'callCourier', name:'callCourier' , component: () => import('pages/CallCourier.vue') },
    //   { path: 'dashboard', name:'dashboard' , component: () => import('pages/Dashboard.vue')}
    // ],

    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: '/', component: () => import('pages/Iconpage.vue') },
      { path: 'startupPage',name:'startup' , component: () => import('pages/Startup.vue') },
      { path: 'beginner', name:'bgn', component: () => import('pages/Beginner.vue') },
      { path: 'beginnerRg', name:'bgnrg', component: () => import('pages/BeginnerRg.vue') },
      { path: 'intermediate', name:'itm', component: () => import('pages/Intermediate.vue') },
      { path: 'intermediateRg', name:'itmrg', component: () => import('pages/IntermediateRg.vue') },
      { path: 'advanced', name:'adv', component: () => import('pages/Advanced.vue') },
      { path: 'advancedRg', name:'advrg', component: () => import('pages/AdvancedRg.vue') },
      { path: 'levels', name:'levels', component: () => import('pages/Levels.vue') },
      { path: 'signup', name:'signup' , component: () => import('pages/Signup.vue') },
      { path: 'login', name:'login' , component: () => import('pages/Login.vue') },
      { path: 'premium', name:'premium', component: () => import('pages/Premium.vue') },
      { path: 'cancel', name:'cancel', component: () => import('pages/Cancel.vue') },
      { path: 'fullbody1', name:'fullbody', component: () => import('pages/Fullbody1.vue') },
      { path: 'ULpremium', name:'ULpremium', component: () => import('pages/ULpremium.vue') },
      { path: 'ULregular', name:'ULregular', component: () => import('pages/ULregular.vue') },
      { path: 'PPLpremium', name:'PPLpremium', component: () => import('pages/PPLpremium.vue') },
      { path: 'PPLregular', name:'PPLregular', component: () => import('pages/PPLregular.vue') },
      { path: 'fullbodyRg', name:'fullbodyRg', component: () => import('pages/FullbodyRg.vue') }
    ],
  },

  // Always leave this as last one,
  // but you can also remove it
  {
    path: '*',
    component: () => import('pages/Error404.vue')
  }
]

export default routes
