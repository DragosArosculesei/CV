<?php


use App\Http\Controllers\DepoziteController;
use App\Http\Controllers\UtilizatoriController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::prefix('auth')->group(function ($router) {
    Route::post('/login', [UtilizatoriController::class, 'login']);
    Route::get('/login', [UtilizatoriController::class, 'index'])->name('login');
    Route::post('/register', [UtilizatoriController::class, 'register']);
    Route::post('/logout', [UtilizatoriController::class, 'logout']);
    Route::post('/refresh', [UtilizatoriController::class, 'refresh']);
    Route::get('/user-profile', [UtilizatoriController::class, 'userProfile']);
    Route::post('/user/change-user-type', [UtilizatoriController::class, 'changeUserType']);
    Route::post('/user/change-user-status', [UtilizatoriController::class, 'changeUserTypeToNormal']);

});

// Route::resource('utilizatori', ::class, ['only' => [
//     'index'
// ]]);


