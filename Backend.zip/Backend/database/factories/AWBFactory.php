<?php

namespace Database\Factories;

use App\Models\AWB;
use Illuminate\Database\Eloquent\Factories\Factory;

class AWBFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = AWB::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'awb' => $this->faker->randomNumber(5, false),
            'destAddress' => $this->faker->address(),
            'destName' => $this->faker->name(),
            'destPhone' => $this->faker->phoneNumber(),
            'idStatus' => $this->faker->randomNumber(1, false)
        ];
    }
}
