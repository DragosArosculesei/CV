<?php

namespace Database\Factories;

use App\Models\Comenzi;
use Illuminate\Database\Eloquent\Factories\Factory;

class ComenziFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Comenzi::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'ora_pickup' => $this->faker->dateTime('now'),
            'adresa' => $this->faker->address(),
            'telefon' => $this->faker->phoneNumber(),
            'status' => 'nepreluat'
        ];
    }
}
