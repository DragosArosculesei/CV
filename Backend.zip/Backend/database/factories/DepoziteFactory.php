<?php

namespace Database\Factories;

use App\Models\Depozite;
use Illuminate\Database\Eloquent\Factories\Factory;

class DepoziteFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Depozite::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'depositName' => $this->faker->city()
        ];
    }
}
