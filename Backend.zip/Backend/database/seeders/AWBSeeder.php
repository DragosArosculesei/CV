<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class AWBSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\AWB::factory(30)->create();
    }
}
